29/29/2018

# This program is developed in the Clion under the Mac OSX High Sierra. 
# Note that this is part of 'Samaritan', a C package for evolutionary multi-objective optimization study. Since 'Samaritan' is still under development, more comprehensive functions will be released later.
